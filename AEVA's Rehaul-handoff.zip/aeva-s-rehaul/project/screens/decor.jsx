/* AEVA — Decorations recommendations
   Signature move: each card has a "mood" with a tiny color palette
   stripe + the kit list (what physically arrives). */

const Decor = ({ onNavigate, tweaks = {} }) => {
  const accent = tweaks.accent || 'var(--aeva-ember)';
  const [expanded, setExpanded] = React.useState(0);
  const [mood, setMood] = React.useState('all');

  const decorators = [
    { id: 0, name: 'Petal & Pine', studio: 'Brooklyn floral studio', price: 620, img: PHOTOS.florist, score: 95,
      mood: 'Warm Trattoria', tags: ['Florals', 'Candles', 'Italian'],
      palette: ['#C44E1C', '#D9A05B', '#7A5C2E', '#F2EEE7', '#1A1814'],
      kit: [
        '6× low arrangements (garden roses, ranunculus, eucalyptus)',
        '24× taper candles, ivory + amber glass holders',
        'Hand-lettered table cards · linen napkins',
        'String of warm Edison bulbs over the bar',
      ],
      why: [
        { match: 'Vibe', detail: 'Warm earth-tones echo The Wythe Loft\'s brick — feels like the room, not pasted on.' },
        { match: 'Budget', detail: 'At $620, leaves $580 for music + photography combined.' },
      ]
    },
    { id: 1, name: 'The Bloom Bar', studio: 'Mobile florist · Williamsburg', price: 480, img: PHOTOS.weddingGarden, score: 88,
      mood: 'Wild Garden', tags: ['Florals', 'Garden', 'Looser'],
      palette: ['#D9A05B', '#A8B89E', '#F2D9C4', '#FAF8F5', '#4A453E'],
      kit: [
        '4× tall, loose meadow arrangements',
        'Bud vases scattered (12 stems)',
        'Beeswax pillar candles',
      ],
      why: [
        { match: 'Vibe', detail: 'Looser, less formal — a touch younger than your "intimate, lively" cue.' },
        { match: 'Budget', detail: 'Cheapest qualified · saves $140 vs. Petal & Pine.' },
      ]
    },
    { id: 2, name: 'Studio Halcyon', studio: 'Full-service event design', price: 980, img: PHOTOS.toast, score: 82,
      mood: 'Editorial Modern', tags: ['Sculptural', 'Minimal'],
      palette: ['#1A1814', '#FAF8F5', '#C9C0AE', '#C44E1C'],
      kit: [
        'Sculptural single-stem ikebana centerpieces',
        'Black taper candles in brass holders',
        'Custom printed menus (letterpress)',
        'Two large floor arrangements at the bar',
      ],
      why: [
        { match: 'Note', detail: 'Striking but reads more gallery-opening than birthday — could feel cold for 24.' },
        { match: 'Budget', detail: 'Stretches your $700 line by $280; trade-offs needed.' },
      ]
    },
    { id: 3, name: 'Rosewater', studio: 'Vintage rentals + florals', price: 720, img: PHOTOS.weddingTable, score: 86,
      mood: 'Romantic Heirloom', tags: ['Vintage', 'Pastels'],
      palette: ['#F2D9C4', '#E8C4A0', '#C9A87A', '#8A8278', '#FAF8F5'],
      kit: [
        '6× mismatched-china tablescape (vintage rentals)',
        'Garden roses + sweet peas, low + lush',
        'Beeswax candles in cut-glass holders',
      ],
      why: [
        { match: 'Vibe', detail: 'Sweet and slightly grandma-house — depends on Maya\'s taste.' },
      ]
    },
    { id: 4, name: 'Neon & Bloom', studio: 'Florals + lighting', price: 850, img: PHOTOS.partyLights, score: 79,
      mood: 'Disco Ember', tags: ['Lighting', 'Bold', 'Music-led'],
      palette: ['#C44E1C', '#7A2E5C', '#1A1814', '#D9A05B'],
      kit: [
        'Custom neon "Maya 30" sign',
        'Disco-ball cluster over the dance floor',
        'Bold red-orange floral spikes (3)',
        'Amber up-lights on brick walls',
      ],
      why: [
        { match: 'Vibe', detail: 'Goes hard on "lively." Could overwhelm dinner — pair with subtler centerpieces.' },
      ]
    },
    { id: 5, name: 'Whitebox Studios', studio: 'DIY rental kit (delivered)', price: 320, img: PHOTOS.cocktail, score: 84,
      mood: 'DIY Curated', tags: ['DIY', 'Affordable'],
      palette: ['#FAF8F5', '#E4DED2', '#C9C0AE', '#1A1814'],
      kit: [
        'Pre-assembled centerpiece kit (you place)',
        'Candle bundles + holders',
        'Step-by-step setup card',
      ],
      why: [
        { match: 'Budget', detail: 'Half the price of Petal & Pine — frees $300 for upgrades elsewhere.' },
        { match: 'Trade-off', detail: 'You (or a friend) sets up; figure 90 min before doors.' },
      ]
    },
  ];

  return (
    <div style={{ maxWidth: 1280, margin: '0 auto', padding: '40px 32px 80px' }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 32, gap: 32, flexWrap: 'wrap' }}>
        <div>
          <button className="btn btn-quiet btn-sm" onClick={() => onNavigate('catering')} style={{ marginBottom: 16, marginLeft: -10 }}>
            <Icon name="chevronLeft" size={13}/> Back to catering
          </button>
          <p className="t-eyebrow" style={{ marginBottom: 8 }}>Step 3 of 4 · decor</p>
          <h1 className="t-display-lg" style={{ marginBottom: 12, maxWidth: 720 }}>Set the room before guests walk in.</h1>
          <p className="t-body-lg" style={{ color: 'var(--aeva-ink-soft)', maxWidth: 600 }}>
            Each option is a complete look, with the actual kit that arrives the day-of. Tap to open.
          </p>
        </div>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          {['all', 'florals', 'lighting', 'minimal', 'under $500'].map(f => (
            <button key={f} onClick={() => setMood(f)} style={{ padding: '8px 14px', borderRadius: 999, background: mood === f ? 'var(--aeva-ink)' : 'var(--aeva-canvas)', color: mood === f ? 'var(--aeva-paper)' : 'var(--aeva-ink-soft)', border: mood === f ? 'none' : '1px solid var(--aeva-line)', fontSize: 12.5, fontWeight: 500, cursor: 'pointer', textTransform: 'capitalize' }}>{f}</button>
          ))}
        </div>
      </div>

      {/* Brief strip */}
      <div style={{ display: 'flex', gap: 16, padding: '14px 20px', background: 'var(--aeva-paper-warm)', border: '1px solid var(--aeva-line)', borderRadius: 'var(--r-md)', marginBottom: 32, alignItems: 'center', flexWrap: 'wrap' }}>
        <Icon name="flower" size={16} style={{ color: accent }}/>
        <span style={{ fontSize: 12.5, color: 'var(--aeva-ink-soft)' }}>Designing for:</span>
        <Tag size="sm">The Wythe Loft (brick + Edison)</Tag>
        <Tag size="sm">6 tables · 24 seats</Tag>
        <Tag size="sm" tone="ember">Warm · Intimate</Tag>
        <Tag size="sm">~$700 line</Tag>
        <button className="btn btn-quiet btn-sm" style={{ marginLeft: 'auto', fontSize: 12 }}>Edit mood <Icon name="edit" size={11}/></button>
      </div>

      {/* Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20 }}>
        {decorators.map(d => {
          const isExpanded = expanded === d.id;
          return (
            <div key={d.id} onClick={() => setExpanded(d.id)} style={{ background: 'var(--aeva-canvas)', border: `1px solid ${isExpanded ? 'var(--aeva-ink)' : 'var(--aeva-line)'}`, borderRadius: 'var(--r-lg)', overflow: 'hidden', cursor: 'pointer', transition: 'all 240ms', boxShadow: isExpanded ? 'var(--shadow-lg)' : 'none' }}
              onMouseEnter={e => !isExpanded && (e.currentTarget.style.borderColor = 'var(--aeva-line-strong)')}
              onMouseLeave={e => !isExpanded && (e.currentTarget.style.borderColor = 'var(--aeva-line)')}>

              {/* Image with palette stripe */}
              <div style={{ position: 'relative', height: 200 }}>
                <img src={d.img} style={{ width: '100%', height: '100%', objectFit: 'cover' }}/>
                <div style={{ position: 'absolute', top: 12, left: 12, padding: '6px 10px', background: 'rgba(26,24,20,0.85)', backdropFilter: 'blur(6px)', borderRadius: 999, color: 'white', fontSize: 11, fontWeight: 600, display: 'flex', alignItems: 'center', gap: 5 }}>
                  <Icon name="sparkles" size={10} style={{ color: accent }}/>
                  {d.score}% match
                </div>
                <button style={{ position: 'absolute', top: 12, right: 12, width: 32, height: 32, borderRadius: '50%', background: 'rgba(255,255,255,0.95)', border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }} onClick={e => e.stopPropagation()}>
                  <Icon name="bookmark" size={14}/>
                </button>
                {/* Palette stripe — sits on bottom of image */}
                <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, display: 'flex', height: 8 }}>
                  {d.palette.map((c, j) => <div key={j} style={{ flex: 1, background: c }}/>)}
                </div>
              </div>

              {/* Body */}
              <div style={{ padding: 18 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 6, gap: 12 }}>
                  <div>
                    <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 18, fontWeight: 480, fontVariationSettings: "'opsz' 36" }}>{d.name}</h3>
                    <p style={{ fontSize: 11, color: 'var(--aeva-ink-mute)', fontFamily: 'var(--font-mono)', letterSpacing: '0.04em', textTransform: 'uppercase', marginTop: 3 }}>Mood · {d.mood}</p>
                  </div>
                  <span style={{ fontSize: 14, fontWeight: 600, whiteSpace: 'nowrap' }}>${d.price}</span>
                </div>
                <p style={{ fontSize: 12.5, color: 'var(--aeva-ink-mute)', marginBottom: 10, display: 'flex', alignItems: 'center', gap: 5 }}>
                  <Icon name="mapPin" size={11}/> {d.studio}
                </p>
                <div style={{ display: 'flex', gap: 5, flexWrap: 'wrap', marginBottom: 14 }}>
                  {d.tags.map(t => <Tag key={t} size="sm">{t}</Tag>)}
                </div>

                {/* Expanded */}
                <div style={{ overflow: 'hidden', maxHeight: isExpanded ? 720 : 0, transition: 'max-height 360ms ease' }}>
                  <div style={{ paddingTop: 14, borderTop: '1px solid var(--aeva-line)' }}>
                    {/* Kit list */}
                    <p className="t-eyebrow" style={{ marginBottom: 10 }}>What arrives</p>
                    <ul style={{ margin: 0, padding: 0, listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 14 }}>
                      {d.kit.map((k, j) => (
                        <li key={j} style={{ display: 'flex', gap: 10, fontSize: 12.5, color: 'var(--aeva-ink-soft)', lineHeight: 1.45 }}>
                          <Icon name="check" size={12} style={{ color: 'var(--aeva-sage)', marginTop: 3, flexShrink: 0 }}/>
                          <span>{k}</span>
                        </li>
                      ))}
                    </ul>

                    {/* Why */}
                    <p className="t-eyebrow" style={{ marginBottom: 10, display: 'flex', alignItems: 'center', gap: 6 }}>
                      <Icon name="sparkles" size={11} style={{ color: accent }}/> Why AEVA picked this
                    </p>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 14 }}>
                      {d.why.map((r, j) => (
                        <div key={j} style={{ display: 'flex', gap: 10 }}>
                          <span style={{ width: 6, height: 6, borderRadius: '50%', background: accent, marginTop: 7, flexShrink: 0 }}/>
                          <div style={{ minWidth: 0 }}>
                            <span style={{ fontSize: 11.5, fontWeight: 600, color: 'var(--aeva-ink)', marginRight: 8 }}>{r.match}</span>
                            <span style={{ fontSize: 12.5, color: 'var(--aeva-ink-soft)', lineHeight: 1.5 }}>{r.detail}</span>
                          </div>
                        </div>
                      ))}
                    </div>

                    <div style={{ display: 'flex', gap: 8 }}>
                      <button className="btn btn-ember btn-sm" style={{ flex: 1 }} onClick={e => { e.stopPropagation(); onNavigate('vendors'); }}>
                        Pick this look
                      </button>
                      <button className="btn btn-ghost btn-sm" onClick={e => e.stopPropagation()}>
                        <Icon name="eye" size={13}/>
                      </button>
                    </div>
                  </div>
                </div>

                {!isExpanded && (
                  <div style={{ fontSize: 12, color: 'var(--aeva-ink-soft)', display: 'inline-flex', alignItems: 'center', gap: 4 }}>
                    Tap to see the kit <Icon name="arrowRight" size={11}/>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Continue bar */}
      <div style={{ marginTop: 32, padding: 20, background: 'var(--aeva-canvas)', border: '1px solid var(--aeva-line)', borderRadius: 'var(--r-md)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <Icon name="check" size={16} style={{ color: 'var(--aeva-sage)' }}/>
          <span style={{ fontSize: 13.5 }}>Petal & Pine selected · <span style={{ color: 'var(--aeva-ink-mute)' }}>2 more steps to go</span></span>
        </div>
        <button className="btn btn-primary" onClick={() => onNavigate('vendors')}>
          Continue to vendors <Icon name="arrowRight" size={14}/>
        </button>
      </div>
    </div>
  );
};

window.Decor = Decor;
