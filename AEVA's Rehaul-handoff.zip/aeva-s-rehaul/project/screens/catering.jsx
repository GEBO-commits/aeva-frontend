/* AEVA — Catering recommendations
   Same shell vocabulary as Recommendations (venues), but signature
   move: each card flips to show a sample tasting menu + dietary fit. */

const Catering = ({ onNavigate, tweaks = {} }) => {
  const accent = tweaks.accent || 'var(--aeva-ember)';
  const [expanded, setExpanded] = React.useState(0);
  const [filter, setFilter] = React.useState('all');

  const caterers = [
    { id: 0, name: 'Sunday Supper Co.', cuisine: 'Italian · Family-style', area: 'Brooklyn', price: 48, total: 1152, img: PHOTOS.catering, score: 96, tags: ['Family-style', 'Vegetarian-friendly'],
      menu: [
        { course: 'Antipasti', items: 'Burrata · marinated olives · focaccia' },
        { course: 'Primi', items: 'Cacio e pepe · short rib pappardelle' },
        { course: 'Dolci', items: 'Tiramisu cups · espresso' },
      ],
      diet: { vegetarian: true, vegan: 'on request', gf: true, halal: false },
      why: [
        { match: 'Vibe', detail: 'Family-style serving keeps the table conversational — fits your "intimate, lively" cue.' },
        { match: 'Diet fit', detail: '4 of your guests are vegetarian; their menu has 3 strong vegetarian primi.' },
        { match: 'Budget', detail: '$48/head × 24 = $1,152 — leaves $400 in your food line.' },
      ]
    },
    { id: 1, name: 'Saltwater Kitchen', cuisine: 'Coastal Mediterranean', area: 'Red Hook', price: 62, total: 1488, img: PHOTOS.cocktail, score: 88, tags: ['Plated', 'Seafood'],
      menu: [
        { course: 'Starter', items: 'Crudo · sea-salt cucumber' },
        { course: 'Main', items: 'Branzino al forno · saffron orzo' },
        { course: 'Dessert', items: 'Lemon olive-oil cake' },
      ],
      diet: { vegetarian: 'limited', vegan: false, gf: true, halal: false },
      why: [
        { match: 'Note', detail: 'Stronger seafood lean — 2 of your guests don\'t do shellfish; ask about a swap.' },
        { match: 'Vibe', detail: 'Plated service feels more formal than your brief.' },
      ]
    },
    { id: 2, name: 'Sobremesa', cuisine: 'Spanish tapas · Sharing', area: 'Williamsburg', price: 42, total: 1008, img: PHOTOS.toast, score: 92, tags: ['Tapas', 'Sharing', 'Late-night'],
      menu: [
        { course: 'To start', items: 'Pan con tomate · jamón · gildas' },
        { course: 'Sharing', items: 'Tortilla · gambas al ajillo · padrón' },
        { course: 'Sweet', items: 'Crema catalana' },
      ],
      diet: { vegetarian: true, vegan: true, gf: true, halal: false },
      why: [
        { match: 'Vibe', detail: 'Tapas pacing is naturally sociable — keeps people moving.' },
        { match: 'Budget', detail: 'Cheapest qualified option; saves $144 vs. Sunday Supper.' },
      ]
    },
    { id: 3, name: 'The Provisions Table', cuisine: 'New American · Seasonal', area: 'Carroll Gardens', price: 55, total: 1320, img: PHOTOS.weddingTable, score: 84, tags: ['Plated', 'Seasonal'],
      menu: [
        { course: 'First', items: 'Stone-fruit salad · whipped ricotta' },
        { course: 'Main', items: 'Coal-roasted chicken · summer beans' },
        { course: 'Dessert', items: 'Peach galette' },
      ],
      diet: { vegetarian: true, vegan: 'on request', gf: 'on request', halal: false },
      why: [
        { match: 'Note', detail: 'Solid all-arounder, but plated service may feel stiff for 24.' },
      ]
    },
    { id: 4, name: 'Smoke & Stone BBQ', cuisine: 'Texas BBQ · Buffet', area: 'Bushwick', price: 38, total: 912, img: PHOTOS.partyLights, score: 76, tags: ['Buffet', 'Casual'],
      menu: [
        { course: 'The board', items: 'Brisket · pulled pork · sausage links' },
        { course: 'Sides', items: 'Mac · slaw · cornbread · pickles' },
        { course: 'Sweet', items: 'Banana pudding' },
      ],
      diet: { vegetarian: 'limited', vegan: false, gf: true, halal: false },
      why: [
        { match: 'Note', detail: 'Reads more cookout than 30th-birthday — flag if the vibe is more polished.' },
      ]
    },
    { id: 5, name: 'Banchan Social', cuisine: 'Korean · Sharing', area: 'Greenpoint', price: 50, total: 1200, img: PHOTOS.birthdayCake, score: 90, tags: ['Sharing', 'Bold flavors'],
      menu: [
        { course: 'Banchan', items: 'Six little dishes, refilled' },
        { course: 'Mains', items: 'Galbi · tofu kimchi jjigae · bibimbap bowls' },
        { course: 'Dessert', items: 'Hotteok · sesame ice cream' },
      ],
      diet: { vegetarian: true, vegan: true, gf: 'on request', halal: false },
      why: [
        { match: 'Vibe', detail: 'Bold, communal, memorable — strong "lively" signal.' },
        { match: 'Diet fit', detail: 'Excellent vegan + gluten-free coverage.' },
      ]
    },
  ];

  const dietBadge = (label, value) => {
    const tones = { true: 'sage', false: 'ghost', 'on request': 'neutral', 'limited': 'neutral' };
    const fg = { true: 'var(--aeva-sage)', false: 'var(--aeva-ink-mute)', 'on request': 'var(--aeva-ink-soft)', 'limited': 'var(--aeva-ink-soft)' };
    const symbol = value === true ? '✓' : value === false ? '–' : '~';
    return (
      <div style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 11, color: fg[String(value)] }}>
        <span style={{ width: 16, height: 16, borderRadius: 4, background: value === true ? 'var(--aeva-sage-soft)' : 'var(--aeva-paper-warm)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontWeight: 600, fontFamily: 'var(--font-mono)' }}>{symbol}</span>
          {label}{typeof value === 'string' && value !== 'true' && value !== 'false' && <span style={{ color: 'var(--aeva-ink-mute)', marginLeft: 2 }}>· {value}</span>}
      </div>
    );
  };

  return (
    <div style={{ maxWidth: 1280, margin: '0 auto', padding: '40px 32px 80px' }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 32, gap: 32, flexWrap: 'wrap' }}>
        <div>
          <button className="btn btn-quiet btn-sm" onClick={() => onNavigate('recommendations')} style={{ marginBottom: 16, marginLeft: -10 }}>
            <Icon name="chevronLeft" size={13}/> Back to venues
          </button>
          <p className="t-eyebrow" style={{ marginBottom: 8 }}>Step 2 of 4 · catering</p>
          <h1 className="t-display-lg" style={{ marginBottom: 12, maxWidth: 720 }}>Six caterers Maya's guests will actually eat.</h1>
          <p className="t-body-lg" style={{ color: 'var(--aeva-ink-soft)', maxWidth: 600 }}>
            Sorted by fit against your dietary mix and the room you picked. Tap any card to open the tasting menu.
          </p>
        </div>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          {['all', 'family-style', 'plated', 'buffet', 'vegetarian-friendly'].map(f => (
            <button key={f} onClick={() => setFilter(f)} style={{ padding: '8px 14px', borderRadius: 999, background: filter === f ? 'var(--aeva-ink)' : 'var(--aeva-canvas)', color: filter === f ? 'var(--aeva-paper)' : 'var(--aeva-ink-soft)', border: filter === f ? 'none' : '1px solid var(--aeva-line)', fontSize: 12.5, fontWeight: 500, cursor: 'pointer', textTransform: 'capitalize' }}>{f}</button>
          ))}
        </div>
      </div>

      {/* Brief strip */}
      <div style={{ display: 'flex', gap: 16, padding: '14px 20px', background: 'var(--aeva-paper-warm)', border: '1px solid var(--aeva-line)', borderRadius: 'var(--r-md)', marginBottom: 32, alignItems: 'center', flexWrap: 'wrap' }}>
        <Icon name="utensils" size={16} style={{ color: accent }}/>
        <span style={{ fontSize: 12.5, color: 'var(--aeva-ink-soft)' }}>Feeding:</span>
        <Tag size="sm">24 guests</Tag>
        <Tag size="sm">4 vegetarian</Tag>
        <Tag size="sm">1 gluten-free</Tag>
        <Tag size="sm">No shellfish (2)</Tag>
        <Tag size="sm" tone="ember">~$50/head budget</Tag>
        <button className="btn btn-quiet btn-sm" style={{ marginLeft: 'auto', fontSize: 12 }}>Edit dietary <Icon name="edit" size={11}/></button>
      </div>

      {/* Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20 }}>
        {caterers.map(c => {
          const isExpanded = expanded === c.id;
          return (
            <div key={c.id} onClick={() => setExpanded(c.id)} style={{ background: 'var(--aeva-canvas)', border: `1px solid ${isExpanded ? 'var(--aeva-ink)' : 'var(--aeva-line)'}`, borderRadius: 'var(--r-lg)', overflow: 'hidden', cursor: 'pointer', transition: 'all 240ms', boxShadow: isExpanded ? 'var(--shadow-lg)' : 'none' }}
              onMouseEnter={e => !isExpanded && (e.currentTarget.style.borderColor = 'var(--aeva-line-strong)')}
              onMouseLeave={e => !isExpanded && (e.currentTarget.style.borderColor = 'var(--aeva-line)')}>

              {/* Image */}
              <div style={{ position: 'relative', height: 200 }}>
                <img src={c.img} style={{ width: '100%', height: '100%', objectFit: 'cover' }}/>
                <div style={{ position: 'absolute', top: 12, left: 12, padding: '6px 10px', background: 'rgba(26,24,20,0.85)', backdropFilter: 'blur(6px)', borderRadius: 999, color: 'white', fontSize: 11, fontWeight: 600, display: 'flex', alignItems: 'center', gap: 5 }}>
                  <Icon name="sparkles" size={10} style={{ color: accent }}/>
                  {c.score}% match
                </div>
                <button style={{ position: 'absolute', top: 12, right: 12, width: 32, height: 32, borderRadius: '50%', background: 'rgba(255,255,255,0.95)', border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }} onClick={e => e.stopPropagation()}>
                  <Icon name="bookmark" size={14}/>
                </button>
              </div>

              {/* Body */}
              <div style={{ padding: 18 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 6, gap: 12 }}>
                  <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 18, fontWeight: 480, fontVariationSettings: "'opsz' 36" }}>{c.name}</h3>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ fontSize: 14, fontWeight: 600 }}>${c.price}<span style={{ fontSize: 11, color: 'var(--aeva-ink-mute)', fontWeight: 400 }}>/head</span></div>
                    <div style={{ fontSize: 11, color: 'var(--aeva-ink-mute)', fontFamily: 'var(--font-mono)' }}>${c.total} total</div>
                  </div>
                </div>
                <p style={{ fontSize: 12.5, color: 'var(--aeva-ink-mute)', marginBottom: 10, display: 'flex', alignItems: 'center', gap: 5 }}>
                  <Icon name="utensils" size={11}/> {c.cuisine} · {c.area}
                </p>
                <div style={{ display: 'flex', gap: 5, flexWrap: 'wrap', marginBottom: 14 }}>
                  {c.tags.map(t => <Tag key={t} size="sm">{t}</Tag>)}
                </div>

                {/* Expanded: menu + diet + why */}
                <div style={{ overflow: 'hidden', maxHeight: isExpanded ? 720 : 0, transition: 'max-height 360ms ease' }}>
                  <div style={{ paddingTop: 14, borderTop: '1px solid var(--aeva-line)' }}>
                    {/* Sample menu */}
                    <p className="t-eyebrow" style={{ marginBottom: 10 }}>Sample tasting menu</p>
                    <div style={{ background: 'var(--aeva-paper-warm)', borderRadius: 'var(--r-sm)', padding: 12, marginBottom: 14 }}>
                      {c.menu.map((m, j) => (
                        <div key={j} style={{ display: 'flex', gap: 10, paddingBottom: j < c.menu.length - 1 ? 8 : 0, marginBottom: j < c.menu.length - 1 ? 8 : 0, borderBottom: j < c.menu.length - 1 ? '1px dashed var(--aeva-line-strong)' : 'none' }}>
                          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10.5, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--aeva-ink-mute)', width: 64, flexShrink: 0, paddingTop: 2 }}>{m.course}</span>
                          <span style={{ fontSize: 12.5, color: 'var(--aeva-ink)', lineHeight: 1.45 }}>{m.items}</span>
                        </div>
                      ))}
                    </div>

                    {/* Diet matrix */}
                    <p className="t-eyebrow" style={{ marginBottom: 10 }}>Dietary coverage</p>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6, marginBottom: 14 }}>
                      {dietBadge('Vegetarian', c.diet.vegetarian)}
                      {dietBadge('Vegan', c.diet.vegan)}
                      {dietBadge('Gluten-free', c.diet.gf)}
                      {dietBadge('Halal', c.diet.halal)}
                    </div>

                    {/* Why */}
                    <p className="t-eyebrow" style={{ marginBottom: 10, display: 'flex', alignItems: 'center', gap: 6 }}>
                      <Icon name="sparkles" size={11} style={{ color: accent }}/> Why AEVA picked this
                    </p>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 14 }}>
                      {c.why.map((r, j) => (
                        <div key={j} style={{ display: 'flex', gap: 10 }}>
                          <span style={{ width: 6, height: 6, borderRadius: '50%', background: accent, marginTop: 7, flexShrink: 0 }}/>
                          <div style={{ minWidth: 0 }}>
                            <span style={{ fontSize: 11.5, fontWeight: 600, color: 'var(--aeva-ink)', marginRight: 8 }}>{r.match}</span>
                            <span style={{ fontSize: 12.5, color: 'var(--aeva-ink-soft)', lineHeight: 1.5 }}>{r.detail}</span>
                          </div>
                        </div>
                      ))}
                    </div>

                    <div style={{ display: 'flex', gap: 8 }}>
                      <button className="btn btn-ember btn-sm" style={{ flex: 1 }} onClick={e => { e.stopPropagation(); onNavigate('decor'); }}>
                        Pick this caterer
                      </button>
                      <button className="btn btn-ghost btn-sm" onClick={e => e.stopPropagation()}>
                        <Icon name="eye" size={13}/>
                      </button>
                    </div>
                  </div>
                </div>

                {!isExpanded && (
                  <div style={{ fontSize: 12, color: 'var(--aeva-ink-soft)', display: 'inline-flex', alignItems: 'center', gap: 4 }}>
                    Tap to see the menu <Icon name="arrowRight" size={11}/>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Continue bar */}
      <div style={{ marginTop: 32, padding: 20, background: 'var(--aeva-canvas)', border: '1px solid var(--aeva-line)', borderRadius: 'var(--r-md)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <Icon name="check" size={16} style={{ color: 'var(--aeva-sage)' }}/>
          <span style={{ fontSize: 13.5 }}>Sunday Supper Co. selected · <span style={{ color: 'var(--aeva-ink-mute)' }}>3 more steps to go</span></span>
        </div>
        <button className="btn btn-primary" onClick={() => onNavigate('decor')}>
          Continue to decorations <Icon name="arrowRight" size={14}/>
        </button>
      </div>
    </div>
  );
};

window.Catering = Catering;
